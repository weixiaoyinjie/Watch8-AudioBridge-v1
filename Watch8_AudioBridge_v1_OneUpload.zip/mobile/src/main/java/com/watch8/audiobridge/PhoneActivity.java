package com.watch8.audiobridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.wearable.CapabilityClient;
import com.google.android.gms.wearable.Wearable;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Phone receives automatically in the listener service; this screen is a lightweight file manager. */
public final class PhoneActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() { if (visible) { render(); handler.postDelayed(this, 6000L); } }
    };
    private LinearLayout content;
    private TextView status;
    private MediaPlayer player;
    private Uri playingUri;
    private boolean visible;

    private static final class Entry {
        Uri uri;
        String name;
        long size;
        long added;
        long duration;
        Entry(Uri uri, String name, long size, long added, long duration) {
            this.uri = uri; this.name = name; this.size = size;
            this.added = added; this.duration = duration;
        }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF0F141C);
        getWindow().setNavigationBarColor(0xFF0F141C);
        ScrollView root = new ScrollView(this);
        root.setBackgroundColor(0xFF0F141C);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(23), dp(18), dp(20));
        root.addView(content);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        visible = true;
        handler.removeCallbacks(refresh);
        refresh.run();
    }

    @Override protected void onPause() {
        visible = false;
        handler.removeCallbacks(refresh);
        stopPlayback();
        super.onPause();
    }

    private void render() {
        int scrollY = 0;
        if (content.getParent() instanceof ScrollView) scrollY = ((ScrollView) content.getParent()).getScrollY();
        content.removeAllViews();
        TextView title = label("Watch8 录音同步", 23, Color.WHITE, true);
        content.addView(title);
        status = label("正在检查手表连接…", 13, 0xFFB4C5D3, false);
        space(5);
        content.addView(status);
        updateConnection();
        space(13);
        TextView tip = label("手表录音结束后自动同步到手机。未连接时手表保留原文件，连接恢复后重试。", 13, 0xFFB1BEC9, false);
        content.addView(tip);
        space(15);
        Button reload = button("刷新录音列表", 0xFF2B554D);
        content.addView(reload, new LinearLayout.LayoutParams(-1, dp(42)));
        reload.setOnClickListener(v -> render());
        space(17);
        List<Entry> list = listSaved();
        TextView count = label("已同步文件 · " + list.size() + " 条", 16, Color.WHITE, true);
        content.addView(count);
        space(8);
        if (list.isEmpty()) {
            TextView empty = label("暂无录音\n请先在手表上录音并结束，等待自动同步。", 14, 0xFF9AAABD, false);
            empty.setPadding(dp(8), dp(35), dp(8), dp(20));
            content.addView(empty);
        }
        for (Entry e : list) addEntry(e);
        TextView footer = label("文件保存在 Music/Watch8AudioBridge，格式为通用 M4A。手机端删除不会自动删除手表原文件。", 12, 0xFF8093A3, false);
        space(18);
        content.addView(footer);
        if (content.getParent() instanceof ScrollView) {
            final int y = scrollY;
            content.post(() -> ((ScrollView) content.getParent()).scrollTo(0, y));
        }
    }

    private void updateConnection() {
        final TextView target = status;
        try {
            Wearable.getCapabilityClient(this)
                    .getCapability("watch8_audio_bridge_watch", CapabilityClient.FILTER_REACHABLE)
                    .addOnSuccessListener(info -> {
                        if (target != status || !visible) return;
                        target.setText(info.getNodes().isEmpty()
                                ? "手表未连接 / 尚未安装手表端" : "● 手表已连接 · 自动同步可用");
                    })
                    .addOnFailureListener(e -> {
                        if (target == status) target.setText("暂时无法读取手表连接状态");
                    });
        } catch (Exception e) { target.setText("此设备暂不支持 Wear OS 同步"); }
    }

    private List<Entry> listSaved() {
        List<Entry> out = new ArrayList<>();
        String[] columns = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.DURATION};
        String selection = MediaStore.Audio.Media.RELATIVE_PATH + "=? AND "
                + MediaStore.Audio.Media.IS_PENDING + "=0";
        try (Cursor c = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                columns, selection, new String[]{PhoneReceiverService.AUDIO_DIR},
                MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
            if (c == null) return out;
            while (c.moveToNext()) {
                String filename = c.getString(1);
                if (filename != null && filename.endsWith(".m4a")) {
                    out.add(new Entry(ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)), filename,
                            c.getLong(2), c.getLong(3), c.getLong(4)));
                }
            }
        } catch (Exception e) { Toast.makeText(this, "读取手机录音失败", Toast.LENGTH_SHORT).show(); }
        return out;
    }

    private void addEntry(Entry entry) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(0xFF1C2732, 13));
        card.setPadding(dp(12), dp(11), dp(12), dp(12));
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, -2);
        outer.bottomMargin = dp(10);
        content.addView(card, outer);
        TextView name = label(entry.name, 13, Color.WHITE, true);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        card.addView(name);
        spaceIn(card, 5);
        String desc = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
                .format(new Date(entry.added * 1000L)) + " · "
                + String.format(Locale.US, "%.2f MB", entry.size / 1048576.0)
                + (entry.duration > 0 ? " · " + formatDuration(entry.duration) : "");
        card.addView(label(desc, 12, 0xFFAAB9C5, false));
        spaceIn(card, 10);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(buttons);
        Button play = button(entry.uri.equals(playingUri) ? "停止" : "播放", 0xFF2C5951);
        buttons.addView(play, weight());
        play.setOnClickListener(v -> { togglePlayback(entry.uri); play.setText(entry.uri.equals(playingUri) ? "停止" : "播放"); });
        Button share = button("分享", 0xFF34516E);
        LinearLayout.LayoutParams sp = weight(); sp.leftMargin = dp(7);
        buttons.addView(share, sp);
        share.setOnClickListener(v -> shareFile(entry));
        Button remove = button("删除", 0xFF633538);
        LinearLayout.LayoutParams rp = weight(); rp.leftMargin = dp(7);
        buttons.addView(remove, rp);
        remove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("删除手机上这条录音？")
                .setMessage("只删除手机文件，手表的录音不受影响。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d,w) -> {
                    if (entry.uri.equals(playingUri)) stopPlayback();
                    try {
                        getContentResolver().delete(entry.uri, null, null);
                        render();
                    } catch (Exception e) { Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show(); }
                }).show());
    }

    private void togglePlayback(Uri uri) {
        if (uri.equals(playingUri)) { stopPlayback(); render(); return; }
        stopPlayback();
        try {
            MediaPlayer next = new MediaPlayer();
            next.setDataSource(this, uri);
            next.setOnCompletionListener(mp -> { stopPlayback(); render(); });
            next.setOnErrorListener((mp, what, extra) -> {
                stopPlayback(); Toast.makeText(this, "播放失败", Toast.LENGTH_SHORT).show();
                return true;
            });
            next.prepare();
            next.start();
            player = next;
            playingUri = uri;
        } catch (Exception e) { stopPlayback(); Toast.makeText(this, "无法播放", Toast.LENGTH_SHORT).show(); }
        render();
    }

    private void stopPlayback() {
        playingUri = null;
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    private void shareFile(Entry entry) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("audio/mp4");
        share.putExtra(Intent.EXTRA_STREAM, entry.uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(share, "分享录音")); }
        catch (Exception e) { Toast.makeText(this, "找不到分享应用", Toast.LENGTH_SHORT).show(); }
    }

    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0, dp(39), 1f); }
    private void space(int h) { spaceIn(content, h); }
    private void spaceIn(LinearLayout p, int h) {
        View empty = new View(this);
        p.addView(empty, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private TextView label(String value, int sp, int color, boolean strong) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (strong) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String label, int bg) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setPadding(0,0,0,0);
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setMinHeight(0); b.setMinimumHeight(0);
        b.setBackground(roundRect(bg, 8));
        return b;
    }
    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private String formatDuration(long ms) {
        long s = ms / 1000L;
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); stopPlayback(); super.onDestroy(); }
}
