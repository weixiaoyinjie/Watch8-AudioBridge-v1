package com.watch8.audiobridge;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.wearable.ChannelClient;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Receives files while the phone UI is closed. Publish only after exact size/hash match. */
public final class PhoneReceiverService extends WearableListenerService {
    public static final String AUDIO_DIR = Environment.DIRECTORY_MUSIC + "/Watch8AudioBridge/";
    private static final String AUDIO_PREFIX = "/watch8rec/audio/v1/";
    private static final String ACK_PATH = "/watch8rec/ack/v1";
    private static final long MAX_SIZE = 220L * 1024L * 1024L;
    private static final String TAG = "Watch8Receiver";
    @Override public void onChannelOpened(ChannelClient.Channel channel) {
        final String path = channel.getPath();
        if (path == null || !path.startsWith(AUDIO_PREFIX)) return;
        // WearableListenerService callbacks have their own background Looper.
        // Complete the transfer within the callback so Play services keeps this
        // listener bound while the file is being received.
        receive(channel);
    }

    private void receive(ChannelClient.Channel channel) {
        String filename = "";
        File part = null;
        ChannelClient client = Wearable.getChannelClient(this);
        try {
            String[] fields = channel.getPath().substring(AUDIO_PREFIX.length()).split("/");
            if (fields.length != 3) throw new IllegalArgumentException("Unexpected channel path");
            filename = fields[0];
            if (!filename.matches("Watch8Rec_[A-Za-z0-9_]+\\.m4a"))
                throw new IllegalArgumentException("Invalid filename");
            long expectedSize = Long.parseLong(fields[1]);
            String expectedSha = fields[2];
            if (expectedSize <= 0 || expectedSize > MAX_SIZE || !expectedSha.matches("[a-f0-9]{64}"))
                throw new IllegalArgumentException("Invalid file metadata");

            part = File.createTempFile("watch8_recv_", ".part", getCacheDir());
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long received = 0;
            try (InputStream in = Tasks.await(client.getInputStream(channel), 30, TimeUnit.SECONDS);
                 OutputStream out = new FileOutputStream(part)) {
                byte[] buffer = new byte[32768];
                int length;
                while ((length = in.read(buffer)) != -1) {
                    if (length == 0) continue;
                    received += length;
                    if (received > expectedSize) throw new IllegalStateException("Overlong transfer");
                    out.write(buffer, 0, length);
                    digest.update(buffer, 0, length);
                }
                out.flush();
            }
            if (received != expectedSize || !expectedSha.equals(hex(digest.digest()))) {
                throw new IllegalStateException("File check failed; keep pending on watch");
            }
            if (!alreadyStored(filename, expectedSize)) publish(part, filename);
            // Only a durable, verified, published file qualifies for this ACK.
            Tasks.await(Wearable.getMessageClient(this).sendMessage(channel.getNodeId(), ACK_PATH,
                    filename.getBytes(StandardCharsets.UTF_8)), 15, TimeUnit.SECONDS);
        } catch (Exception failure) {
            Log.w(TAG, "Phone receive failed: " + filename, failure);
        } finally {
            if (part != null) part.delete();
            try { Tasks.await(client.close(channel), 10, TimeUnit.SECONDS); }
            catch (Exception ignored) { }
        }
    }

    private boolean alreadyStored(String name, long size) {
        String where = MediaStore.Audio.Media.RELATIVE_PATH + "=? AND "
                + MediaStore.Audio.Media.DISPLAY_NAME + "=? AND "
                + MediaStore.Audio.Media.IS_PENDING + "=0";
        String[] args = {AUDIO_DIR, name};
        try (Cursor c = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media.SIZE}, where, args, null)) {
            while (c != null && c.moveToNext()) if (c.getLong(0) == size) return true;
        }
        return false;
    }

    private void publish(File part, String name) throws Exception {
        ContentValues meta = new ContentValues();
        meta.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
        meta.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
        meta.put(MediaStore.Audio.Media.RELATIVE_PATH, AUDIO_DIR);
        meta.put(MediaStore.Audio.Media.IS_PENDING, 1);
        Uri target = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, meta);
        if (target == null) throw new IllegalStateException("Cannot add phone recording");
        boolean okay = false;
        try {
            try (InputStream in = new FileInputStream(part);
                 OutputStream out = getContentResolver().openOutputStream(target, "w")) {
                if (out == null) throw new IllegalStateException("Cannot write phone recording");
                byte[] buf = new byte[32768];
                int count;
                while ((count = in.read(buf)) >= 0) if (count > 0) out.write(buf, 0, count);
                out.flush();
            }
            ContentValues finished = new ContentValues();
            finished.put(MediaStore.Audio.Media.IS_PENDING, 0);
            okay = getContentResolver().update(target, finished, null, null) > 0;
            if (!okay) throw new IllegalStateException("Cannot finalize phone recording");
        } finally {
            if (!okay) {
                try { getContentResolver().delete(target, null, null); }
                catch (Exception ignored) { }
            }
        }
    }

    private static String hex(byte[] bytes) {
        StringBuilder text = new StringBuilder(64);
        for (byte v : bytes) text.append(String.format(Locale.US, "%02x", v & 0xff));
        return text.toString();
    }
}
