# Watch8 AudioBridge v1 · Galaxy Watch 8 + Android Phone

这是**全新包名**的两个 APK 项目（不是旧版 App 的更新包），一个 ZIP 同时包含：

- `wear/`：Galaxy Watch 8 的一键后台录音 + 录音管理；
- `mobile/`：安卓手机自动接收、播放、分享、删除手表录音；
- `.github/workflows/build_both_apks.yml`：完整源码展开至 GitHub 仓库时直接编译两个 APK。

## 手表操作

**两个独立 Launcher 快捷方式：**

1. **一键录音**：点一次开始，再点一次停止保存，再点一次开始新录音。
2. **录音管理**：查看、试听、分享、删除、音质设置、手动申请同步；每条录音显示“待同步”或“已同步”。

如果三星系统允许，在手表 **设置 > 高级功能 > 自定义按键 / Home 键双击 > 打开应用** 选择“一键录音”。App 不能自行重新映射系统按键，也无法保证实体键自身不会唤亮屏幕。录音启动后不会主动保持屏幕点亮；Android 持续显示其要求的录音权限/隐私指示及前台服务通知。**首次安装必须在屏幕上授权麦克风。**

## 音质与录音格式

- AAC-LC / M4A，单声道 24,000 Hz，48 kbps。驱动不支持 24 kHz 时尝试 16 kHz。
- 每小时约 22 MB（48 kbps 的理论值约 21.6 MB/h，M4A 封装略有开销）。
- 系统支持时启用 `NoiseSuppressor` 降噪与 `AutomaticGainControl` 自动增益；附带轻度 90 Hz 高通滤波与软件 AGC 回退。
- 可设自动、0 dB、+3 dB、+6 dB。为减少爆音，软件路径含峰值限制。
- 真实效果受 Watch 8 固件和系统音频驱动影响，不能保证所有机型均支持硬件降噪/自动增益。
- 录音存储在手表的 `Music/Watch8AudioBridge`；文件结束封装后才触发自动同步。

## 自动同步机制

- 使用官方 Wear OS Data Layer `CapabilityClient` + `ChannelClient` 流传输，不依赖第三方账号或手机和手表处在同一 Wi-Fi。
- 必须在**配对安卓手机**和 **Watch 8** 上都安装对应版本，且两者 APK **包名和签名证书相同**。GitHub Actions 在**同一 job** 编译两端 Debug APK，默认使用同一调试签名。
- 成功保存每条 M4A 后触发同步；如暂时找不到手机配对端则保留在手表；周期任务每 15 分钟检查一次（Android 可能推迟执行，非实时保证）。
- 手机验证**长度 + SHA-256**、成功发布文件至 `Music/Watch8AudioBridge/` 后发回确认；没有确认则手表继续显示“待同步”，不会自动删除源文件。
- 每次处理最多四条录音，避免过度唤醒。失败等待后重新尝试；手表“录音管理”可手动点击“同步到手机”。
- 手机端在后台通过 `WearableListenerService` 接收文件，不需要手机界面始终打开；是否能够实际接收仍受系统后台策略、Google Play 服务及蓝牙/网络连接影响。
- 删除手机端文件不会自动删除手表文件；删除手表文件也不会删除手机备份。

## 构建 APK

### 方式一：上传已解压源码

将 **本 ZIP 解压后**的所有文件上传到 GitHub 仓库根目录，`settings.gradle` 必须在根目录。
在 **Actions > Build Watch8 AudioBridge (Phone + Wear) > Run workflow** 或 push 至 `main`/`master` 后，下载 `Watch8-AudioBridge-Wear-and-Phone-APKs`。内含：

- `Watch8_AudioBridge_WEAR.apk`
- `Watch8_AudioBridge_PHONE.apk`

### 方式二：GitHub 只上传一个 ZIP，不需要解压（推荐）

1. 在一个**新建的 GitHub 仓库**根目录上传 `Watch8_AudioBridge_v1_OneUpload.zip`，不要改名。
2. 在仓库用 **Add file > Create new file** 创建 `.github/workflows/build.yml`。
3. 把附件 `GitHub_OneUpload_build.yml` 的**全部内容**复制粘贴进去，提交。
4. 在 **Actions > Build Watch8 AudioBridge OneUpload > Run workflow**，或者提交后触发自动构建。
5. 打开成功的 run，下载 **Watch8-AudioBridge-Two-APKs** 产物，里面有两个 APK。

> 注意：单独上传 ZIP 不会让 GitHub 自动发现 ZIP 内部的 workflow，必须单独在仓库建立 `.github/workflows/build.yml`。这是 GitHub 的机制，不是 ZIP 问题。

### 本地构建

要求 JDK 17、Android SDK 35、Gradle 8.9（或 Android Studio 对应版本）。源代码根目录：

```bash
gradle :wear:assembleDebug :mobile:assembleDebug
```

默认产物路径：

```
wear/build/outputs/apk/debug/wear-debug.apk
mobile/build/outputs/apk/debug/mobile-debug.apk
```

## 安装注意

- 安装 `Watch8_AudioBridge_PHONE.apk` 到安卓手机；`Watch8_AudioBridge_WEAR.apk` 到 Galaxy Watch 8。
- 这是新的 `applicationId=com.watch8.audiobridge`，不会覆盖旧版 `com.watch8.onetaprecorder`。旧版录音文件也不会自动导入。
- 如果日后换了签名密钥，安卓可能拒绝覆盖安装。先备份本地文件后再决定如何升级。
- 三星/Android 安全设置可能提示“未知来源”或 Play Protect；不保证第三方 APK 会被系统允许安装。

## 实施范围与限制

**实现源码已生成，但目前未在此环境编译 APK 或 Galaxy Watch 8 真机上联调。**
因此首次上机建议测试：麦克风授权、第一次/第二次/第三次单击行为、Home 双击映射、熄屏录音、系统支持的音频处理、传输大文件、接收中断与断线重试。
本项目不尝试规避 Android 麦克风隐私提示或未经用户授权录音。
