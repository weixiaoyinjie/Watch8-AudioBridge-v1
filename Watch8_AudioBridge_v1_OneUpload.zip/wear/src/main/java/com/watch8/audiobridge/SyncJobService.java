package com.watch8.audiobridge;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.wearable.CapabilityClient;
import com.google.android.gms.wearable.CapabilityInfo;
import com.google.android.gms.wearable.ChannelClient;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Watch -> phone: stream original M4A, verify SHA-256 on phone, await independent ack. */
public final class SyncJobService extends JobService {
    private static final String TAG = "Watch8Sync";
    private static final AtomicBoolean BUSY = new AtomicBoolean(false);
    private volatile boolean cancelled;

    private static final class Recording {
        final Uri uri;
        final String name;
        final long size;
        Recording(Uri uri, String name, long size) {
            this.uri = uri; this.name = name; this.size = size;
        }
    }

    @Override public boolean onStartJob(JobParameters params) {
        if (!BUSY.compareAndSet(false, true)) return false;
        cancelled = false;
        new Thread(() -> {
            boolean retry = false;
            try { retry = runSync(); }
            catch (Exception e) { retry = true; Log.w(TAG, "Sync job failed", e); }
            finally {
                BUSY.set(false);
                if (!cancelled) jobFinished(params, retry);
            }
        }, "Watch8-ChannelSync").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        cancelled = true;
        return true;
    }

    private boolean runSync() throws Exception {
        List<Recording> recordings = listPending();
        if (recordings.isEmpty() || cancelled) return false;
        CapabilityInfo phone = Tasks.await(Wearable.getCapabilityClient(this).getCapability(
                SyncScheduler.PHONE_CAPABILITY, CapabilityClient.FILTER_REACHABLE),
                15, TimeUnit.SECONDS);
        Node target = null;
        for (Node n : phone.getNodes()) {
            if (n.isNearby()) { target = n; break; }
            if (target == null) target = n;
        }
        if (target == null) return false; // Periodic job will check again later.
        ChannelClient channels = Wearable.getChannelClient(this);
        int sent = 0;
        for (Recording file : recordings) {
            if (cancelled || sent >= 4) break; // Bound battery and data use per job.
            if (!SyncScheduler.canAttempt(this, file.name)) continue;
            SyncScheduler.markAttempt(this, file.name);
            ChannelClient.Channel channel = null;
            boolean completed = false;
            try {
                String sha = digest(file.uri);
                String path = SyncScheduler.AUDIO_PATH + file.name + "/" + file.size + "/" + sha;
                channel = Tasks.await(channels.openChannel(target.getId(), path), 30, TimeUnit.SECONDS);
                try (InputStream in = getContentResolver().openInputStream(file.uri);
                     OutputStream out = Tasks.await(channels.getOutputStream(channel), 30, TimeUnit.SECONDS)) {
                    if (in == null) throw new IllegalStateException("M4A input unavailable");
                    byte[] buf = new byte[32768];
                    int count;
                    while (!cancelled && (count = in.read(buf)) != -1) {
                        out.write(buf, 0, count);
                    }
                    if (cancelled) throw new InterruptedException("Stopped by system");
                    out.flush();
                }
                // Keep channel open until phone verifies and acknowledges. Otherwise a
                // premature close may cut the receiving stream before EOF is processed.
                long deadline = System.currentTimeMillis() + 120_000L;
                while (!cancelled && System.currentTimeMillis() < deadline
                        && !SyncScheduler.isSynced(this, file.name)) {
                    Thread.sleep(300L);
                }
                completed = SyncScheduler.isSynced(this, file.name);
                if (!completed) throw new IllegalStateException("Phone ACK not received in time");
                sent++;
            } catch (Exception e) {
                SyncScheduler.markFailure(this, file.name);
                Log.w(TAG, "Will retry " + file.name, e);
            } finally {
                if (channel != null) {
                    try { Tasks.await(channels.close(channel), 10, TimeUnit.SECONDS); }
                    catch (Exception ignored) { }
                }
            }
            if (!completed && cancelled) break;
        }
        return false; // Never retry in a tight loop. Periodic job remains registered.
    }

    private List<Recording> listPending() {
        List<Recording> files = new ArrayList<>();
        String[] columns = {MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE};
        String selection = MediaStore.Audio.Media.RELATIVE_PATH + "=? AND "
                + MediaStore.Audio.Media.IS_PENDING + "=0";
        try (Cursor c = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                columns, selection, new String[]{RecordingService.RECORDINGS_FOLDER},
                MediaStore.Audio.Media.DATE_ADDED + " ASC")) {
            if (c == null) return files;
            while (c.moveToNext()) {
                String name = c.getString(1);
                long size = c.getLong(2);
                if (name == null || !name.matches("Watch8Rec_[A-Za-z0-9_]+\\.m4a") || size <= 0) continue;
                if (!SyncScheduler.isSynced(this, name)) {
                    files.add(new Recording(ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)), name, size));
                }
            }
        }
        return files;
    }

    private String digest(Uri uri) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("Cannot read audio");
            byte[] buffer = new byte[32768];
            int n;
            while ((n = in.read(buffer)) >= 0) {
                if (cancelled) throw new InterruptedException("Cancelled");
                if (n > 0) md.update(buffer, 0, n);
            }
        }
        StringBuilder hex = new StringBuilder(64);
        for (byte b : md.digest()) hex.append(String.format(Locale.US, "%02x", b & 0xff));
        return hex.toString();
    }
}
