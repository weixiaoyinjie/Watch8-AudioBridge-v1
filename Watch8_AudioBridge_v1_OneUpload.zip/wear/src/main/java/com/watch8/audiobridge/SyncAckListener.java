package com.watch8.audiobridge;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;
import java.nio.charset.StandardCharsets;

/** Only confirmed, fully written phone files are marked synced. */
public final class SyncAckListener extends WearableListenerService {
    @Override public void onMessageReceived(MessageEvent event) {
        if (!SyncScheduler.ACK_PATH.equals(event.getPath())) return;
        String name = new String(event.getData(), StandardCharsets.UTF_8);
        if (name.matches("Watch8Rec_[A-Za-z0-9_]+\\.m4a")) {
            SyncScheduler.markSynced(this, name);
            // If multiple recordings await transfer, process the next one.
            SyncScheduler.requestNow(this);
        }
    }
}
