package com.watch8.audiobridge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-establish retry scheduling; never start microphone capture after reboot. */
public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            SyncScheduler.ensurePeriodic(context);
            SyncScheduler.requestNow(context);
        }
    }
}
