package com.watch8.audiobridge;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Same two Wear OS shortcuts. The foreground microphone service continues after screen-off. */
public final class RecordingService extends Service {
    public static final String ACTION_TOGGLE = "com.watch8.audiobridge.TOGGLE";
    public static final String ACTION_STOP = "com.watch8.audiobridge.STOP";
    public static final String EVENT_RESULT = "com.watch8.audiobridge.RESULT";
    public static final String EXTRA_ERROR = "error";
    public static final String RECORDINGS_FOLDER = Environment.DIRECTORY_MUSIC + "/Watch8AudioBridge/";
    private static final String CHANNEL_ID = "watch8_mic_capture";
    private static final int NOTIFICATION_ID = 1001;
    private static volatile boolean recording = false;
    private AudioCaptureEngine engine;
    private Uri currentUri;
    private ParcelFileDescriptor outputFd;
    private boolean ownsForeground;
    private boolean saving;
    private boolean restartAfterSave;
    private final Handler main = new Handler(Looper.getMainLooper());

    public static boolean isRecording() { return recording; }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            restartAfterSave = false;
            if (engine != null && !saving) requestStop();
            sendResult(null);
            if (engine == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_TOGGLE.equals(action)) {
            if (saving) {
                // A third click just after stop requests a brand-new recording.
                restartAfterSave = true;
                sendResult(null);
            } else if (engine != null) {
                requestStop();
                sendResult(null);
            } else {
                String failure = beginRecording();
                sendResult(failure);
                if (failure != null) stopSelf();
            }
            return START_NOT_STICKY;
        }
        if (engine == null) stopSelf();
        return START_NOT_STICKY;
    }

    private String beginRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "麦克风权限未授权";
        }
        try {
            createChannel();
            startForeground(NOTIFICATION_ID, createNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            ownsForeground = true;
            ContentValues values = new ContentValues();
            String filename = "Watch8Rec_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
                    .format(new Date()) + ".m4a";
            values.put(MediaStore.Audio.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            values.put(MediaStore.Audio.Media.RELATIVE_PATH, RECORDINGS_FOLDER);
            values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            currentUri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (currentUri == null) throw new IOException("无法创建录音文件");
            outputFd = getContentResolver().openFileDescriptor(currentUri, "w");
            if (outputFd == null) throw new IOException("无法打开录音文件");
            engine = new AudioCaptureEngine(this, outputFd,
                    (success, error) -> main.post(() -> onCaptureFinished(success, error)));
            engine.prepare();
            recording = true;
            engine.start();
            return null;
        } catch (Exception ex) {
            if (engine != null) engine.requestStop();
            engine = null;
            recording = false;
            discardCurrent();
            removeForeground();
            return "录音失败：" + ex.getClass().getSimpleName();
        }
    }

    private void requestStop() {
        if (engine == null) return;
        recording = false;
        saving = true;
        engine.requestStop();
    }

    private void onCaptureFinished(boolean success, String error) {
        // Happens on main thread after AAC and MP4 finalization finishes.
        engine = null;
        saving = false;
        recording = false;
        closeFd();
        if (success && currentUri != null) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Audio.Media.IS_PENDING, 0);
                success = getContentResolver().update(currentUri, values, null, null) > 0;
            } catch (Exception ex) { success = false; }
        }
        if (!success) {
            discardCurrent();
            sendResult(error == null ? "录音保存失败" : error);
        }
        if (success) SyncScheduler.afterRecording(this);
        currentUri = null;
        if (restartAfterSave) {
            restartAfterSave = false;
            String failure = beginRecording();
            sendResult(failure);
            if (failure == null) return;
        }
        removeForeground();
        stopSelf();
    }

    private void closeFd() {
        if (outputFd != null) {
            try { outputFd.close(); } catch (IOException ignored) { }
            outputFd = null;
        }
    }
    private void discardCurrent() {
        closeFd();
        if (currentUri != null) {
            try { getContentResolver().delete(currentUri, null, null); }
            catch (Exception ignored) { }
            currentUri = null;
        }
    }
    private void removeForeground() {
        if (ownsForeground) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            ownsForeground = false;
        }
    }
    private void sendResult(String error) {
        Intent update = new Intent(EVENT_RESULT).setPackage(getPackageName());
        if (error != null) update.putExtra(EXTRA_ERROR, error);
        sendBroadcast(update);
    }
    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                getString(R.string.recording_channel), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("录音时持续显示状态和停止按钮");
        channel.enableVibration(false);
        channel.setSound(null, null);
        nm.createNotificationChannel(channel);
    }
    private Notification createNotification() {
        Intent openManager = new Intent(this, ManagerActivity.class);
        openManager.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 20, openManager,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, RecordingService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 21, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notif_mic)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(getString(R.string.notification_text))
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(R.drawable.ic_notif_mic,
                        "停止并保存", stopAction).build())
                .build();
    }
    @Override public void onDestroy() {
        if (engine != null) engine.requestStop();
        removeForeground();
        recording = false;
        super.onDestroy();
    }
}
