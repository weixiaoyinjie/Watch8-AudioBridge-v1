package com.watch8.audiobridge;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.audiofx.AutomaticGainControl;
import android.media.audiofx.NoiseSuppressor;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.util.Log;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Mono PCM capture -> device supported NoiseSuppressor/AGC -> low-cut and peak-safe
 * manual gain -> hardware AAC encoder -> universally playable MPEG-4/M4A container.
 * Runs entirely on a dedicated thread after a user-initiated foreground service starts.
 */
final class AudioCaptureEngine implements Runnable {
    interface Callback { void finished(boolean success, String error); }

    static final String PREF_NAME = "audio_quality";
    static final String PREF_NS = "noise_suppression";
    static final String PREF_GAIN = "gain_mode";
    static final String GAIN_AUTO = "auto";
    static final String GAIN_0 = "0";
    static final String GAIN_3 = "3";
    static final String GAIN_6 = "6";
    private static final int BITRATE = 48000;
    private static final int CHANNELS = 1;
    private static final long MAX_ENCODED_BYTES = 200L * 1024L * 1024L;
    private static final String TAG = "Watch8AudioCapture";

    private final Context context;
    private final ParcelFileDescriptor output;
    private final Callback callback;
    private final AtomicBoolean active = new AtomicBoolean(true);
    private Thread captureThread;
    private AudioRecord audioRecord;
    private MediaCodec codec;
    private MediaMuxer muxer;
    private NoiseSuppressor suppressor;
    private AutomaticGainControl automaticGain;
    private int sampleRate;
    private boolean muxerStarted;
    private int trackIndex = -1;
    private boolean noiseRequested;
    private String gainMode;
    private long framesQueued;
    private long encodedBytes;
    private double lastIn, lastOut, gainEnvelope = 1.0;
    private boolean hasHardwareAgc;
    private final double[] filteredScratch = new double[1024];

    AudioCaptureEngine(Context context, ParcelFileDescriptor output, Callback callback) {
        this.context = context.getApplicationContext();
        this.output = output;
        this.callback = callback;
    }

    void prepare() throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        noiseRequested = prefs.getBoolean(PREF_NS, true);
        gainMode = prefs.getString(PREF_GAIN, GAIN_AUTO);
        Exception lastError = null;
        for (int hz : new int[]{24000, 16000}) {
            try {
                createCapture(hz);
                createEncoder(hz);
                sampleRate = hz;
                break;
            } catch (Exception ex) {
                lastError = ex;
                releaseCaptureAndEncoder();
            }
        }
        if (audioRecord == null || codec == null) {
            throw new IOException("初始化录音设备失败", lastError);
        }
        try {
            muxer = new MediaMuxer(output.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            addAudioEffects();
            audioRecord.startRecording();
            if (audioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                throw new IOException("麦克风没有开始采集");
            }
        } catch (Exception ex) {
            dispose();
            throw ex;
        }
    }

    private void createCapture(int hz) throws IOException {
        int min = AudioRecord.getMinBufferSize(hz, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) throw new IOException("音频采样率不支持: " + hz);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, hz,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                Math.max(min * 2, 8192));
        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
            throw new IOException("AudioRecord 初始化失败");
        }
        // Prefer the watch's built-in microphone over a connected Bluetooth headset.
        AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audio != null) {
            for (AudioDeviceInfo device : audio.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
                if (device.getType() == AudioDeviceInfo.TYPE_BUILTIN_MIC) {
                    audioRecord.setPreferredDevice(device);
                    break;
                }
            }
        }
    }

    private void createEncoder(int hz) throws IOException {
        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        MediaFormat format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, hz, CHANNELS);
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        format.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE);
        format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8192);
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codec.start();
    }

    private void addAudioEffects() {
        int session = audioRecord.getAudioSessionId();
        if (noiseRequested && NoiseSuppressor.isAvailable()) {
            try {
                suppressor = NoiseSuppressor.create(session);
                if (suppressor != null) suppressor.setEnabled(true);
            } catch (Exception ex) {
                Log.w(TAG, "NoiseSuppressor unavailable on this device", ex);
            }
        }
        if (GAIN_AUTO.equals(gainMode) && AutomaticGainControl.isAvailable()) {
            try {
                automaticGain = AutomaticGainControl.create(session);
                if (automaticGain != null) {
                    automaticGain.setEnabled(true);
                    hasHardwareAgc = automaticGain.getEnabled();
                }
            } catch (Exception ex) {
                Log.w(TAG, "AGC unavailable on this device", ex);
            }
        }
    }

    void start() {
        captureThread = new Thread(this, "Watch8-AAC-Recording");
        captureThread.start();
    }

    void requestStop() { active.set(false); }

    @Override public void run() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        String error = null;
        boolean done = false;
        try {
            short[] pcm = new short[1024];
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (active.get()) {
                int slot = codec.dequeueInputBuffer(10000);
                if (slot >= 0) {
                    ByteBuffer input = codec.getInputBuffer(slot);
                    if (input == null) throw new IOException("AAC 输入缓冲区不可用");
                    input.clear();
                    input.order(ByteOrder.LITTLE_ENDIAN);
                    int count = Math.min(pcm.length, input.remaining() / 2);
                    if (count <= 0) throw new IOException("AAC 输入缓冲区过小");
                    int frames = audioRecord.read(pcm, 0, count, AudioRecord.READ_BLOCKING);
                    if (frames < 0) throw new IOException("麦克风读取失败: " + frames);
                    if (frames > 0) {
                        optimizePcm(pcm, frames);
                        for (int i = 0; i < frames; ++i) input.putShort(pcm[i]);
                        long timeUs = framesQueued * 1000000L / sampleRate;
                        codec.queueInputBuffer(slot, 0, frames * 2, timeUs, 0);
                        framesQueued += frames;
                    } else {
                        codec.queueInputBuffer(slot, 0, 0,
                                framesQueued * 1000000L / sampleRate, 0);
                    }
                }
                drain(info, false);
                if (encodedBytes >= MAX_ENCODED_BYTES) active.set(false);
            }
            int slot;
            do { slot = codec.dequeueInputBuffer(10000); if (slot < 0) drain(info, false); }
            while (slot < 0);
            codec.queueInputBuffer(slot, 0, 0, framesQueued * 1000000L / sampleRate,
                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            done = drain(info, true);
        } catch (Exception ex) {
            error = "音频编码失败：" + ex.getClass().getSimpleName();
            Log.e(TAG, "Recording failed", ex);
        } finally {
            boolean success = error == null && done && muxerStarted && encodedBytes > 0;
            if (!success && error == null) error = "录音太短或保存失败";
            boolean finalized = dispose();
            if (!finalized) { success = false; error = "M4A 文件封装失败"; }
            callback.finished(success, error);
        }
    }

    /** Conservative 90 Hz low-cut + gentle, peak-limited input gain. No false claim
     * of deep noise suppression when vendor's hardware effect is unavailable. */
    private void optimizePcm(short[] samples, int n) {
        double alpha = sampleRate / (sampleRate + 2.0 * Math.PI * 90.0);
        double[] filtered = filteredScratch;
        double sumSquared = 0.0, peak = 1.0;
        for (int i = 0; i < n; ++i) {
            double x = samples[i];
            double y = noiseRequested ? alpha * (lastOut + x - lastIn) : x;
            lastIn = x;
            lastOut = y;
            filtered[i] = y;
            sumSquared += y * y;
            peak = Math.max(peak, Math.abs(y));
        }
        double requested;
        if (GAIN_AUTO.equals(gainMode)) {
            if (hasHardwareAgc) {
                requested = 1.0;
            } else {
                // Conservative software AGC fallback; never amplify near-silence.
                double rms = Math.sqrt(sumSquared / Math.max(1, n));
                requested = rms < 300.0 ? 1.0 : Math.min(2.0, Math.max(0.75, 4500.0 / rms));
            }
        } else if (GAIN_6.equals(gainMode)) requested = Math.pow(10.0, 6.0 / 20.0);
        else if (GAIN_3.equals(gainMode)) requested = Math.pow(10.0, 3.0 / 20.0);
        else requested = 1.0;
        // Fast attack, slow release; always limit current buffer to avoid clipping.
        double peakSafe = Math.min(requested, 30500.0 / peak);
        gainEnvelope = peakSafe < gainEnvelope ? peakSafe
                : (0.90 * gainEnvelope + 0.10 * peakSafe);
        double actual = Math.min(gainEnvelope, 30500.0 / peak);
        for (int i = 0; i < n; ++i) {
            int sample = (int) Math.round(filtered[i] * actual);
            samples[i] = (short) Math.max(-32767, Math.min(32767, sample));
        }
    }

    private boolean drain(MediaCodec.BufferInfo info, boolean finishing) throws IOException {
        int emptyCount = 0;
        while (true) {
            int index = codec.dequeueOutputBuffer(info, finishing ? 10000 : 0);
            if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!finishing || ++emptyCount > 200) return false;
            } else if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) throw new IOException("音频输出格式多次变化");
                trackIndex = muxer.addTrack(codec.getOutputFormat());
                if (trackIndex < 0) throw new IOException("无法建立音频轨道");
                muxer.start();
                muxerStarted = true;
            } else if (index >= 0) {
                ByteBuffer data = codec.getOutputBuffer(index);
                if (data == null) throw new IOException("AAC 输出缓冲区不可用");
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                if (info.size > 0) {
                    if (!muxerStarted) throw new IOException("封装器尚未开始");
                    data.position(info.offset);
                    data.limit(info.offset + info.size);
                    muxer.writeSampleData(trackIndex, data, info);
                    encodedBytes += info.size;
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                codec.releaseOutputBuffer(index, false);
                if (eos) return true;
            }
        }
    }

    private void releaseCaptureAndEncoder() {
        if (codec != null) {
            try { codec.stop(); } catch (Exception ignored) { }
            try { codec.release(); } catch (Exception ignored) { }
            codec = null;
        }
        if (audioRecord != null) {
            try { audioRecord.release(); } catch (Exception ignored) { }
            audioRecord = null;
        }
    }

    private boolean dispose() {
        boolean finalized = true;
        if (suppressor != null) {
            try { suppressor.release(); } catch (Exception ignored) { }
            suppressor = null;
        }
        if (automaticGain != null) {
            try { automaticGain.release(); } catch (Exception ignored) { }
            automaticGain = null;
        }
        if (audioRecord != null) {
            try { audioRecord.stop(); } catch (Exception ignored) { }
        }
        releaseCaptureAndEncoder();
        if (muxer != null) {
            try { if (muxerStarted) muxer.stop(); } catch (Exception ex) {
                finalized = false;
                Log.w(TAG, "Muxer finalization issue", ex);
            }
            try { muxer.release(); } catch (Exception ignored) { }
            muxer = null;
        }
        return finalized;
    }
}
