package com.watch8.audiobridge;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

/** Durable retry queue: local recordings are never removed on transfer failure. */
public final class SyncScheduler {
    public static final String PHONE_CAPABILITY = "watch8_audio_bridge_phone";
    public static final String AUDIO_PATH = "/watch8rec/audio/v1/";
    public static final String ACK_PATH = "/watch8rec/ack/v1";
    private static final String PREFS = "sync_receipts_v1";
    private static final int NOW_JOB = 6081;
    private static final int PERIODIC_JOB = 6082;
    private static final long RETRY_PERIOD = 15 * 60 * 1000L;

    private SyncScheduler() { }

    public static void afterRecording(Context context) { requestNow(context); }

    public static void ensurePeriodic(Context context) {
        JobScheduler jobs = context.getSystemService(JobScheduler.class);
        if (jobs == null || jobs.getPendingJob(PERIODIC_JOB) != null) return;
        jobs.schedule(new JobInfo.Builder(PERIODIC_JOB, new ComponentName(context, SyncJobService.class))
                .setPeriodic(RETRY_PERIOD)
                .setPersisted(true)
                .build());
    }

    public static void requestNow(Context context) {
        ensurePeriodic(context);
        JobScheduler jobs = context.getSystemService(JobScheduler.class);
        if (jobs == null) return;
        jobs.schedule(new JobInfo.Builder(NOW_JOB, new ComponentName(context, SyncJobService.class))
                .setMinimumLatency(0L)
                .setOverrideDeadline(15_000L)
                .build());
    }

    public static boolean isSynced(Context c, String name) {
        return prefs(c).getBoolean("done:" + name, false);
    }

    public static boolean canAttempt(Context c, String name) {
        if (isSynced(c, name)) return false;
        long last = prefs(c).getLong("attempt:" + name, 0L);
        return System.currentTimeMillis() - last > 120_000L;
    }

    public static void markAttempt(Context c, String name) {
        prefs(c).edit().putLong("attempt:" + name, System.currentTimeMillis()).apply();
    }

    public static void markFailure(Context c, String name) {
        prefs(c).edit().remove("attempt:" + name).apply();
    }

    public static void markSynced(Context c, String name) {
        prefs(c).edit().putBoolean("done:" + name, true).remove("attempt:" + name).apply();
    }

    public static void removeRecord(Context c, String name) {
        prefs(c).edit().remove("done:" + name).remove("attempt:" + name).apply();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
